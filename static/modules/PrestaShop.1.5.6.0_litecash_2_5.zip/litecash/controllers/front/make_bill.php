<?php

class LITEcashMake_BillModuleFrontController extends ModuleFrontController
{
        /**
         * @see FrontController::postProcess()
         */
	public function postProcess()
	{
		
		$cart = $this->context->cart;
		if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
				Tools::redirect('index.php?controller=order&step=1');
		
		$currency = $this->context->currency;
		$id_lang = $this->context->cart->id_lang;
		$lang = new Language($id_lang);
		
		// make order without payments
		$amount_paid = 0;
		$dont_touch_amount = TRUE;
		$id_order_state = $this->module->os_awaiting;
		
		$this->module->validateOrder($cart->id, $id_order_state, $amount_paid, $this->module->name,
			false, false, (int)$currency->id, $dont_touch_amount, false,
			NULL
			);
		
		// get order_id
		$order_id = $this->module->currentOrder;
		
		if (!$order_id) {
			Tools::redirect($this->context->link->getPageLink('history'), true);
		}

		// теперь надо поменять статус у заказа на наш - так как он по умолчанию  в "ОШИБКА ООПЛАТЫ" скидывается
		// так как мы задали 0 оплату в валидайте
		//Db::getInstance()->execute('DELETE FROM '._DB_PREFIX_.'order_history WHERE id_order='.$order_id);
		//$order = new Order($order_id);
		///$order->setCurrentState($id_order_state);
		//$order->total_paid = 0;
		//$order->current_state = $id_order_state;
		//$order->update();
		//$order->setCurrentState($id_order_state);
		
		$price = (float)$cart->getOrderTotal(true, Cart::BOTH);
		$result = $this->module->makeBill($order_id, $price, $currency->iso_code);
		if ($result[1]) {
			//редирект на страницу оплаты
			//Tools::redirect($this->context->link->getPageLink('order-detail', true, NULL, 'id_order='.$order_id));
			Tools::redirect('http://lite.cash/bill/show/'.$result[1]);
		} else {
			// error
			$error = 'LITE.cash payment module ERROR: '.$result[0];
			Logger::addLog($error, 4, '0000001', 'PAYMENT LITE.cash', 1);
			die($error);
		}
		
	}
}

