<?php
/*
author icreator@mail.ru
//trigger_error ( 'result ' . json_encode($result), E_USER_NOTICE );
//p($order);
*/

if (!defined('_PS_VERSION_'))
	exit;

class LITEcash extends PaymentModule
{

	private $_html = '';
	private $_postErrors = array();

	public $merchant_id;
	public $os_awaiting; // state for waiting payment
	private $home_url;
	private $email;
	private $note_url = 'index.php?fc=module&module=litecash&controller=check_bill&';
	private $back_url = 'index.php?controller=order-detail&id_order=';

    static function need_vers() {
		$need_vers = '5.4.13';
		if (version_compare(PHP_VERSION, $need_vers) < 0) {
			$mess = '<strong><font color="red">PHP vers is '.PHP_VERSION.' but need >= ' . $need_vers.'</font></strong>';
			echo $mess;
			return $mess;
		}
	}
	
	public function __construct()
	{
		$this->name = 'litecash';
		$this->tab = 'payments_gateways';
		$this->version = '2.6';
		$this->author = 'LITE.cash';
		$this->module_key='3dfa105ab38d083229c9a8770e869467';
		
		$this->currencies = true;
		$this->currencies_mode = 'checkbox';
		
		$this->merchant_id = Configuration::get('LITE_cash_merchant_id');
		$this->os_awaiting = Configuration::get('LITE_cash_OS_A_PAY');
		$this->email = Configuration::get('PS_SHOP_EMAIL');

		require_once('litecash_lib/admin.php');
		$this->default_settings = get_lib_settings_list();
		$this->default_settings['icon_url'] = 'img/'.Configuration::get('PS_LOGO');
				
		// восстановим или возьмем умолчания
		foreach ( $this->default_settings as $key => $val ) {
			$vv = Configuration::get('LITE_cash_'.$key);
			if ( empty($vv) )
				Configuration::updateValue('LITE_cash_'.$key, $val);
		}

		parent::__construct();

		$this->displayName = 'LITEcash';
		$this->description = $this->l('Accept crypto-currencies payments for your shop via LITE.cash.');
		if ($this->need_vers()) $this->description = $this->need_vers() .'<br>'.$this->description;
		
		$this->confirmUninstall = $this->l('Are you sure about removing these details?');
		if (isset($this->merchant_id)) {
			$this->description .= '<br><div class="conf confirm">Shop ID: '.$this->merchant_id.'</div>';
		} else {
			$this->warning = $this->l('Shop ID must be configured before using this module.');
			if ($this->active) $this->description .= '<br><div class="warn">'.$this->warning.'</div>';
		}
		if (!count(Currency::checkPaymentCurrencies($this->id))) {
			$this->warning = $this->l('No currency has been set for this module.');
			if ($this->active) $this->description .= '<br><div class="warn">'.$this->warning.'</div>';
		}
		

	}

	public function install()
	{
		if ($this->need_vers()) {
			$this->_errors[] = $this->need_vers();
			return false;
		}
		if(!function_exists('curl_version')) {
			$this->_errors[] = $this->l('Sorry, this module requires the cURL PHP extension but it is not enabled on your server.  Please ask your web hosting provider for assistance.')
				.'<br>' . $this->l('Please install cURL library in file php.ini (extension=php_curl.dll)');
			return false;
		}

		if (!parent::install()) return;
		
		foreach (get_class_methods($this) as $hook ) {
			// сравним насала имен без учета регистра
			if ( strncasecmp($hook,'hook', 4) || !strncasecmp($hook,'hookExec', 8)) continue;
			if (!$this->registerHook(substr($hook,4))) return;
		}
			
				// база для заказов
        if(!Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'litecash_bill` (
                            `order_id` int(11) NOT NULL,
                            `bill_id` varchar(40),
                            `status` varchar(10),
                             PRIMARY KEY (`order_id`),
                             KEY `bill_id` (`bill_id`)
                            ) DEFAULT CHARSET=utf8;')) return false;
        
		// база для пополннения депозитов
		if (!Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'litecash_deposit` (
                            `customer_id` int(11) NOT NULL,
                            `bill_id` varchar(40),
                            `status` varchar(10),
							`bal` decimal(16,8),
							`date_modified` date,
                             PRIMARY KEY (`customer_id`),
                             KEY `bill_id` (`bill_id`)
                            ) DEFAULT CHARSET=utf8;')) return false;
		// база транзакций - встроенная customer_transaction

		///
		$this->createOrderState();

		return true;
	}

	public function uninstall()
	{
		foreach ( $this->default_settings as $key => $v ) {
			Configuration::deleteByName('LITE_cash_'.$key);
		}
		
		foreach (get_class_methods($this) as $hook ) {
			// сравним насала имен без учета регистра
			if ( strncasecmp($hook,'hook', 4) || !strncasecmp($hook,'hookExec', 8)) continue;
			$this->unregisterHook(substr($hook,4));
		}
		
		return parent::uninstall();
		
	}

	private function _postValidation() {

		if (Tools::isSubmit('btnSubmit'))
		{
			$mid = Tools::getValue('merchant_id');
			if (!$mid) {
				$this->error_merchant_id = $this->l('Merchant ID are required.');
				$this->_postErrors[] = $this->error_merchant_id . '<br>' . $this->l('See below');
			} else {
				$mid += 0;
				if (!$mid) {
					$this->error_merchant_id = $this->l('Merchant ID must be integer.');
					$this->_postErrors[] = $this->error_merchant_id;
				}
			}
		}
	}

	private function _postProcess()
	{
		foreach ( $this->default_settings as $key  => $v) {
			if ($key == 'currencies_allowed' ) {
				Configuration::updateValue('LITE_cash_'.$key, json_encode(Tools::getValue($key)));
			} else {
				Configuration::updateValue('LITE_cash_'.$key, Tools::getValue($key));
			}
		}
		$this->_html .= '<div class="conf confirm"> '.$this->l('Settings updated').'</div>';

	}
	private function load_settings() {
		$r = array();
		foreach ( $this->default_settings as $key => $v ) {
			$r[$key] = Configuration::get('LITE_cash_'.$key);
		}
		return $r;
	}

	private function _displayForm()	{
		$d = $this->load_settings();
		$d['currencies_allowed'] = json_decode($d['currencies_allowed']);
		
		$action = Tools::htmlentitiesUTF8($_SERVER['REQUEST_URI']);

		$entry_merchant = $this->l('ID магазина:');
		$entry_merchant_addr = $this->l('Адрес Вашего кошелька');
		$quick_reg = $this->l('Быстрая Регистрация');
		$entry_merchant_help = $this->l('Задайте идентификатор Вашего магазина') .
':<UL>' .
'<li>' . $this->l('Пройдите быструю регистрацию по адресу вашего кошелька криптовалюты - заполните') .' "'. $entry_merchant_addr.'" '.
$this->l('и проверьте ссылки на магазин и его иконку, после чего нажмите кнопку').' "'.$quick_reg.'" . ' .
$this->l('Обратите внимание, что заданная криптовалюта должна обслуживаться нашей платежной службой (рекомендуем биткоин)') . '. ' .
$this->l('Так же, все входящие платежи будут автоматически конвертироваться в данную криптовалюту и высылаться незамедлительно на этот адрес, ') . ' ' .
$this->l('а пареметр "Валюта для выплат" не будет учитываться') .
';</li>' .
'<li>' . $this->l('либо получите номер магазина после') .
' <a class="btn- button-" href=\'http://lite.cash/shop_add\' target="_blank"><b>' . $this->l('регистрации в платежной службе') .'</b></a>.</li>' .
'</ul>'.$this->l('В любой момент Вы можете связаться с администацией службы для изменения своих настроек');
		$entry_merchant_val = $this->l('Укажите ID Вашего магазина');
		$entry_merchant_addr_val = $this->l('Укажите адрес Вашего кошелька криптовалюты для быстрой регистрации');
		$button_quick_reg = $this->l('Быстрая Регистрация');
		$txt_home_url = $this->l('Домашняя ссылка магазина');
		$txt_home_url_help = $this->l('Для правильной "быстрой регистрации" открывайте эту админ-панель с удаленного доступа (localhost не подходит!).');
		$txt_icon_url = $this->l('Ссылка на иконку магазина');
		
		$text_payin = $this->l('Валюта для создания счетов оплаты');
		$text_payin_descr = $this->l('Используется текущая валюта магазина');
		$entry_currencies_allowed = $this->l('Список криптовалют, которые разрешены для оплаты счетов').':<br>
			<span class=\'help\'>'.
$this->l('Если ничего не выбрано, то принимаются все криптовалюты, которые обрабатывает платежная служба') .'. ' .
$this->l('Например, Вы можете выбрать только BTC и LTC и задать параметр "Валюта для выплат"="Без конвертации" - тогда пользователь при оплате Вашего счета сможет оплачивать только биткоинами и лайткоинами, которые без конвертации будут поступать Вам на баланс.')
.'</span>';
		$entry_currency_payout = $this->l('"Валюта для выплат", в которую будут конвертироваться входящие платежи').':<br>
			<span class=\'help\'>'.$this->l('В этой валюте Вы будете получать выплаты из платежной службы').'.<br>'
			.$this->l('Если выбрано "без конвертации", то входящая криптовалюта будет зачисляться магазину без ковертации').'.</span>';
		$text_not_convert = $this->l('Без конвертации');
		$text_convert_as_order = $this->l('Конвертировать в валюту заказа');
		$text_public = $this->l('Открытость счетов').'<br>
			<span class=\'help\'>'.$this->l('По умолчанию - "закрыто всем", тогда доступ к информации счетов возможен только с секретнным ключом и они недоступны для посторонних глаз').'.</span>';
		$text_f_public = $this->l('Отметьте если хотите сделать свои счета публичными');
		$text_expire_bill = $this->l('Продолжительность жизни счета в минутах').' <br>
			<span class=\'help\'>'.$this->l('Если значение меньше 10, то берется значение по умолчанию').'.<br>'.$this->l('По умолчанию - 180, максимально - сутки').'. <br/>'
.$this->l('Если счет становится просроченным, то все поступившие на него платежи возвращаются отправителю').'.</span>';
		$text_additional_pars = $this->l('Список дополнительных параметров').':<br>
			<span class=\'help\'>'.$this->l('Более подробно о параметрах').
			' <a href=\'https://docs.google.com/document/d/1hrAocgSS0ZuBvgLr6oS_dKDFhdQwL12qTJCBTaykzSg/edit#heading=h.iii87ixk2pjt\' target=\'_blank\' class=\'link\'>'
			.$this->l('в описании API').'</a></span>';
		$entry_on_bill_status = $this->l('Статус счета, при котором платеж будет считаться принятым, и не ранее которого платежная служба будет присылать уведомления на Ваш сайт').':
			<span class=\'help\'><UL>
			<li>'.$this->l('SOFT - скорость появления статуса 10-30 секунд - подходит для недорогих быстрых услуг').';</li>
			<li>'.$this->l('HARD - (рекомендуется) скорость появления статуса 5-15 минут - подходит для обычных платежей и продаж').';</li>
			<li>'.$this->l('CLOSED - скорость появления статуса 20-40 минут - подходит для платежей больше 10 000 USD').'.</li>
			</ul>'.$this->l('Подробнее о статусах платежей можно прочитать в описании API на сайте платежной службы').'.</span>';
		$entry_order_status = $this->l('Статус заказа после подтверждения оплаты').':<br>
			<span class=\'help\'>'.$this->l('Этот статус автоматически устанавливается после оплаты заказа покупателем и подтверждения со стороны LITE.cash').'</span>';
		$text_default_deposit = $this->l('Величина платежа по умолчанию для пополнения депозита своего счета');
		$text_bonus = $this->l('Скидка для покупателя при оплате данным способом').'<br>
			<span class="help">'.$this->l('Минус даст наценку').'.</span>';

		$text_get_balance = $this->l('Посмотреть свой баланс и резервы в платежной службе').':<br>
			<span class=\'help\'>'.$this->l('Как правило баланс равен нулю, так как все платежи служба автоматически высылает на Ваши кошельки незамедлительно или раз в сутки (как задано при регистрации Вашего магазина в платежной службе)').'</span>';
		$text_get_balance_btn = $this->l('Посмотреть');


		$class = '';
		$list1 = '';
		foreach (array('BTC', 'LTC', 'NVC', 'CLR') as $key) {
			$class = $class == 'even'? 'odd': 'even';
			$list1 .= '
			  <div class="'.$class.'">
				  <label class="pointed"><input type="checkbox" name="currencies_allowed[]" value="'.$key.'"
					'.(is_array($d['currencies_allowed']) && in_array($key, $d['currencies_allowed'])?'checked="checked"':'').' />
				    '.$key.'</label>
			  </div>';
		}
		$currs = array(
				'not_convert' => $text_not_convert,
				'BTC' => 'BTC',
				'LTC' => 'LTC',
				'NVC' => 'NVC',
				'CLR' => 'CLR',
				'AS_IS' => $text_convert_as_order,
				'USD' => 0,
				'EUR' => 0,
				'RUB' => 0,
				); 
		$class = '';
		$list2 = '';
		foreach ($currs as $key => $txt)  {
			$class = ($class == 'even' ? 'odd' : 'even');
			$list2 .= '
				<div class="'.$class.'">
					<label class="pointed"><input type="radio" name="currency_payout" value="'.$key.'"
						'.($d['currency_payout']==$key?'checked="checked"':'').'/>
						'.($txt=='0'?$key:$txt).'
					</label>
				</div>';
		}
		$list3 = '';
		foreach (array('SOFT', 'HARD','CLOSED') as $key) {
			$list3 .= '<option value="'.$key.'" 
					'.($key == $d['on_bill_status']?'selected="selected"':'').'>'.$key.'</option>';
		}
		$list4 = '';
		//foreach ($order_statuses as $key => $name) {
		//	$list4 .= '<option value="'.$key.'" 
		//		'.($key == $order_status_id?'"selected="selected"':'').'>'.$name.'</option>';
		//}

		$btn = '<tr>
				<td><input class="button btn_confirm right" type="submit" name="btnSubmit" value="'.$this->l('Сохранить настройки').'"></td>
				</tr>';

		$this->_html .= '<div class="content">
     <form action="'. $action .'" method="post" enctype="multipart/form-data" id="form">
		<fieldset>
		<legend><img src="../img/admin/contact.gif">'.$this->l('Настройки').'</legend>
            <div class=""><span class=\'help\'>'
				.$entry_merchant_help.'
			</span></div>
        <table class="form">
			'.$btn.'
		
          <div class="form-group required">
		  
            <label for="entry_merchant"><span class="required">*</span>'.$entry_merchant.'</label>
				<input type="text" name="merchant_id" id="merchant_id" value="'.$d['merchant_id'].'" size=20
				placeholder="'.$entry_merchant_val.'" class="form-control"
					/>
				'.($this->error_merchant_id?'<div class="error">'.$this->error_merchant_id.'</div>':'').'
		  </div>
          <div class="form-group">
            <label class="col-sm-3 control-label" for="entry_merchant_addr">'.$entry_merchant_addr.'</label>
            <div class="col-sm-9">
              <input type="text" name="merchant_addr" value="'.$d['merchant_addr'].'" size=70
				placeholder="'.$entry_merchant_addr_val.'" id="merchant_addr" class="form-control" />
				'.($this->error_merchant_addr?'<div class="error">'.$this->error_merchant_addr.'</div>':'').'
            </div>
		  </div>
          <div class="form-group">
                <label class="control-label">'.$txt_home_url.'</label>
				<input type="text" disabled="disabled" size=60 value="'.$this->home_url.'" /><br>
				<span class="help">'.$txt_home_url_help.'</span><br>
				<label class="col-sm-3 control-label">email</label>
				<input type="text" disabled="disabled" value="'.$this->email.'" /><br>
            </div>
			<div class="form-group">
				<label class="col-sm-4">'.$txt_icon_url.'</label>
				<div class="col-sm-5">
					<input type="text" name="icon_url" value="'.$d['icon_url'].'" class="form-control" />
					<img src="'.$this->home_url . $d['icon_url'].'" />
				</div>
			</div>

          <div class="form-group">
			<div class="pull-right">
			<button name="btnQReg" type="submit" value="quick_reg" form="form" data-toggle="tooltip" title="'.$button_quick_reg.'"
				class="button btn_confirm btn btn-primary"><i class="fa fa-plug"></i> '.$quick_reg.'</button>
			</div>
          </div>

			<tr>
                <td>'.$text_payin.'</td>
                <td>'.$text_payin_descr.'</td>
			</tr>
            <tr>
              <td>'.$entry_currencies_allowed.'</td>
              <td valign="top"><div class="scrollbox">
					'.$list1.'
			  </td>
			</tr>
            <tr>
                <td>'.$entry_currency_payout.'</td>
                <td valign="top"><div class="scrollbox payout">
				'.$list2.'
				</td>
            </tr>
            <tr>
                <td>'.$text_public.'</td>
                <td>
					<label class="sublabel"><input type="checkbox" name="public_order" value="public"
						'.($d['public_order']=='public'?'checked="checked"':'').' >
						</input>'.$text_f_public.'</label>
                </td>
            </tr>
			
            <tr>
                <td>'.$text_expire_bill.'</td>
                <td><input type="text" name="expire_bill" value="'.$d['expire_bill'].'" size=6></td>
            </tr>

            <tr>
                <td>'.$text_additional_pars.'</td>
                <td><textarea name="additional_pars" style="width: 400px;height: 150px">
					'.$d['additional_pars'].'</textarea></td>
            </tr>

            <tr>
				<td>'.$entry_on_bill_status.'</td>
				<td><select name="on_bill_status">
					'.$list3.'
				</select></td>
			</tr>
			'
			/*
			<tr>		  
				<td>'.$entry_order_status.'</td>
				<td><select name="order_status_id">
				'.$list4.'
				</select></td>
			</tr>
			*/
			.'<tr>
				<td>'.$text_default_deposit.'</td>
				<td><input type="text" name="default_deposit" value="'.$d['default_deposit'].'" size="6" /></td>
			</tr>
          <tr>
            <td>'.$text_bonus.'</td>
            <td><input type="text" name="bonus" value="'.$d['bonus'].'" size="3" />%</td>
          </tr>
			<tr>
				<td>'.$text_get_balance.'</td>
				<td>
					<a href="http://LITE.cash/api/get_balances/'.$d['merchant_id'].'"
						class="button btn" target="_blank">'.$text_get_balance_btn.'</a>
					</td>
			</tr>
			'.$btn.'
        </table>
		</fieldset>
      </form>
	  </div>
		';
	}
	
	public function getContent()
	{
	
		// внутри запроса можно вычислить адрес сервера
		$port = $_SERVER['SERVER_PORT'];
		$this->home_url = 'http://'.Tools::htmlentitiesUTF8($_SERVER['SERVER_NAME'])
			. ($port==80? '': ':' . $port)
			. __PS_BASE_URI__ ;
		$this->_html = '
		<link type="text/css" rel="stylesheet" href="'._MODULE_DIR_.$this->name.'/views/css/adm01.css" />
		<div id="adm01-wrapper">
			<div class="box half left">
				<a  href="http://LITE.cash" target="_blank">	
				<img src="'._MODULE_DIR_.$this->name.'/logo3.png" alt="" style="margin-bottom: -5px" />
				</a>
				<p id="adm01-slogan"><span class="dark">'.$this->l('LEADER')
				.'</span> <span class="light">'.$this->l('IN BITCOIN PAYMENTS').'</span></p>
				<p>'.$this->l('FASTEST PAYMENT SERVICE').'</p>'
				.$this->l('This module allows you to accept fast worldwide BITCOIN, LITECOIN payments via LITE.cash.').'</b><br /><br />
			</div>

	<div class="box half right">
		<ul class="tick">
				<li><span class="bold">Get more buyers</span><br />100 million-plus crypto-wallets worldwide</li>
				<li><span class="bold">Access international buyers</span><br />225 countries, many crypto-currencies</li>
				<li><span class="bold">Reassure your buyers</span><br />Buyers don’t need to share their private data</li>
				<li><span class="bold">Accept all major payment method</span></li>
		</ul>
	</div>
	<div class="clear"></div>';
	
		$this->error_merchant_id = null;
		$this->error_merchant_addr = null;
		if(!function_exists('curl_version')) {
			$this->_html .= '<div class="error">'
				.$this->l('Please install Curl library in file php.ini (extension=php_curl.dll)').'</div>';
			}
		if (Tools::isSubmit('btnSubmit'))
		{
			$this->_postValidation();
			$this->_postProcess();
				
			if (count($this->_postErrors))
				foreach ($this->_postErrors as $err)
					$this->_html .= '<div class="alert error">'.$err.'</div>';
			}
		elseif (Tools::isSubmit('btnQReg')) {
			$this->_postProcess();

			// quick registration
			// try auto- registration
			$reg_addr = Tools::getValue('merchant_addr');
			if (strlen($reg_addr) <30 ) {
				$this->error_merchant_addr = $this->l('Wallet address length < 30');				
				$this->_html .= '<div class="alert error">'.$this->error_merchant_addr.'</div>';
			} else {
				$reg_pars = array(
					'shop_url' => $this->home_url,
					'icon_url' => Tools::getValue('icon_url'),
					'email'    => $this->email,
					'note_url' => $this->note_url,
					'back_url' => $this->back_url
					);
				$res = lib_quick_reg($reg_addr, $reg_pars);
				
				$reg_id = (int)$res;
				if ($reg_id) {
					if ($reg_id > 0 ) {
						// registration
						$this->_html .= '<div class="conf confirm"> '.$this->name. ' : '.$this->l('Shop registered with:')
						. '<br>URL: ' . $this->home_url
						. '<br>email:' . $this->email.'</div>';
					} else {
						// already registered
						$reg_id = -$reg_id;
						$this->error_merchant_addr = $this->l('That wallet address already_registered. If You want to change settings then use other address.');
						$this->_html .= '<div class="error">'.$this->error_merchant_addr.'</div>';
					}
					Configuration::updateValue('LITE_cash_merchant_id', $reg_id);
				} else {
					$this->error_merchant_addr = $res;
					$this->_html .= '<div class="alert error">'.$res.'</div>';
				}
			}
		}
	
		$this->_displayForm();
		$this->_html .= '</div>'; // закроем врапер

		return $this->_html;
	}

	// показывает способ оплаты при закрытии корзины
	// и переводит на payment.php а оттуда уже подтверждение на validation.php
	// хотя нафиг так сложно - может сразу?
	public function hookPayment($params)
	{
		if (!$this->active)
			return;
		
		$pars = array(
			'error' => false,
			'this_path' => $this->_path,
			'mess' => $this->l('Pay by  LITE.cash') . ' <span>(' . $this->l('BITCOIN and others crypto-currencies') . ')</span>'
			);
		if (!$this->merchant_id) {
			$pars['error'] = '<font color="red">ERROR - merchant_id is empty</font>';
		}

		$this->smarty->assign($pars);
		return $this->display(__FILE__, 'payment_quick.tpl');
	}

	// Action - Display
	public function hookdisplayOrderDetail($params)
	{
		if (!$this->active)
			return;
		
		$order = $params['order'];		
		//$to_pay = $order->total_products - $order->total_paid;
		$current_state = $order->current_state;
		if ($current_state == $this->os_awaiting) $to_pay = 1;
		elseif ($current_state == 2) $to_pay = -1;
		else  $to_pay = 0;
		
		if (!$this->merchant_id) {
			$this->context->smarty->assign(array(
				'error' => 'LITE.cash payment module: ERROR - merchant_id is empty'
				));
		} elseif ($to_pay > 0 ) {
			$currency = new Currency($order->id_currency);

			$result = $this->makeBill($order->id, $to_pay, $currency->iso_code);
			//trigger_error ( 'result ' . json_encode($result), E_USER_NOTICE );
			$error = $result[0];
			$bill_id = $result[1];
			
			if ($error) {
				$this->context->smarty->assign(array(
					'error' => $error
					));
			} else {
				$cs = $order->getCurrentStateFull($this->context->language->id);
				//$user_data = $this->db->getRow($sql);

				$this->context->smarty->assign(array(
					'error' => FALSE,
					'state' => $cs['name'],
					'real_paid' => $order->total_paid_real,
					'price' => $order->total_paid,
					'to_pay' => $to_pay,
					'currency' => $currency,
					'show_bill' => 'http://LITE.cash/bill/show/'.$bill_id,
					));
			}
		} else {
			$this->context->smarty->assign(array(
				'error' => FALSE,
				'to_pay' => $to_pay,
				));
		}
		return $this->display(__FILE__, 'order_detail.tpl');

	}

	
	public function checkCurrency($cart)
	{
		return true;
	}

	public function createOrderState()
	{
		
		if ($this->os_awaiting) {
			return true;
		}

		$order_state = new OrderState();
		$order_state->module_name = $this->name;
		$mess = 'Awaiting payment via LITE.cash';
		$order_state->name = array_fill(0,10, $mess ); // для десяти языков

		foreach (Language::getLanguages() as $language)
		{
			if (Tools::strtolower($language['iso_code']) == 'ru')
				$order_state->name[$language['id_lang']] = 'Ожидание оплаты из LITE.cash';
			else
				$order_state->name[$language['id_lang']] = $mess;
		}

		$order_state->send_email = false;
		$order_state->color = '#DDEEFF';
		$order_state->hidden = false;
		$order_state->delivery = false;
		$order_state->logable = false; // not make payment record
		$order_state->invoice = false;
		$order_state->paid = false;

		if ($order_state->add())
		{
			$icon = dirname(__FILE__).'/os_pending.gif';
			$state_icon = dirname(__FILE__).'/../../img/os/'.(int)$order_state->id.'.gif';
			copy($icon, $state_icon);
			Configuration::updateValue('LITE_cash_OS_A_PAY', (int)$order_state->id);
			$this->os_awaiting = (int)$order_state->id;
			return true;
		}

	}
	
	public function makeBill($order_id = NULL, $total = NULL, $curr = NULL) {
	
		$order_id = $order_id? $order_id:  $this->currentOrder;
		
		$row = Db::getInstance()->getRow('select bill_id from '._DB_PREFIX_.'litecash_bill where order_id='.$order_id, false);
		
        if($row) {
			// да - счет создан, просто его вернем
            $result=$row['bill_id'];
			return array(NULL, $result);
		}

		// если за использование данного способа дается скидка
		$bonus = (float)Configuration::get('LITE_cash_bonus');
		$bonus_txt = '';
		if ($bonus != 0 ) {
			$total *= (1 - $bonus/100);
			// если способ оплаты с бонусом то покажем это
			if ($bonus > 0) $txt = $this->l('Discount');
			else  $txt = $this->l('Markup');
			$bonus_txt = '. <b>'. $txt . ' ' . abs($bonus) . '%</b>';
		}
		
		// load settings
		require_once('litecash_lib/admin.php');
		$info = array();
		foreach (get_lib_settings_list() as $key => $v)
			$info[$key] = Configuration::get('LITE_cash_' . $key);
		// decode str to list
		$info['currencies_allowed'] = json_decode($info['currencies_allowed']);
		$info['order_id'] = $order_id;
		$info['curr'] = $curr;
		$info['price'] = $total;
		$info['lang'] = $this->context->language->iso_code; // берет из сукиес инфоо

		// make order
		require_once('litecash_lib/make.php');
		$result = make_order_bill($info);
		if ($result[1]) {
			// save  bill_id + secret key
			Db::getInstance()->execute('insert ignore into '._DB_PREFIX_.'litecash_bill set order_id='
				.$order_id.', bill_id="'.$result[1].'"');
		}
		return $result;
	}
	
	// callback
	public function checkBill($params) {
	
		return 'eeee';
		$history = new OrderHistory();
		$history->id_order = (int)$id_order;
		$history->changeIdOrderState((int)Configuration::get('PS_OS_REFUND'), $history->id_order);
		$history->addWithemail();
		$history->save();

		// 	public function addOrderPayment($amount_paid, $payment_method = null, $payment_transaction_id = null, $currency = null, $date = null, $order_invoice = null)
		$order->addOrderPayment($amount_paid, null, $transaction_id);
	}
}
