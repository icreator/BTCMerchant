<?php

/**
 * @since 1.5.oo
 */

 // ?fc=module&module=LITEcash&controller=Check_Bill&order=38
 
//class LITEcashCheck_BillModuleFrontController extends ModuleFrontController
class LITEcashCheck_BillModuleFrontController

{

	public function run() {
		
		$bill_id=Tools::getValue('bill');
        $order_id=Tools::getValue('order');
		$order = new Order($order_id);
		if (!Validate::isLoadedObject($order)) {
			d('Can\'t load Order');
		}

		$row = Db::getInstance()->getRow('select bill_id from '._DB_PREFIX_.'litecash_bill where order_id='.$order_id, false);

		if (!$row) {
			d('LITEcashCheck_BillModuleFrontController ERROR: order not found');
		}
		//foreach ($rows as $row) p($row);
		$bill_key=$row['bill_id'];
		$on_status = Configuration::get('LITE_cash_on_bill_status');
		require_once('/../../litecash_lib/check.php');
		$res = check_status($bill_key, $on_status);
		//p($res);
		$st = (int)$res;
		if (!$st) {
			// error
			d($res);
		}
		if ($st>0) {
			if ($order->current_state == (int)Configuration::get('PS_OS_PAYMENT')) return;
						
			// add payment
			$order->addOrderPayment($order->total_paid, 'LIITEcash');
			
			// chabge order state
			$new_history = new OrderHistory();
			$new_history->id_order = $order_id;
			$new_history->changeIdOrderState(Configuration::get('PS_OS_PAYMENT'), $order, true);
			//$new_history->save(); twice make record
			$extra_vars= null;
			$new_history->addWithemail(true, $extra_vars);
			
			p('add new status');

		} elseif ($res<0) {
			if ($order->current_state == (int)Configuration::get('PS_OS_PAYMENT')) return;
			
			p('status = expired');
		} else {
			d('status = NEW or FILL');
		}
	}


}